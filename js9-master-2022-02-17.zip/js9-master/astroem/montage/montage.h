#ifndef MONTAGE
extern FILE *fstatus;
#define MONTAGE
#endif
